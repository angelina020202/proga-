﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _321321
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

		// ПАРСЕР ФОРМУЛ (ПОЛУЧАЕМ РЕЗУЛЬТАТ ВЫЧИСЛЕНИЯ ФОРМУЛЫ)
		class FORMULAPARSING
		{
			// FORMULAPARSING fm = new FORMULAPARSING("3 * (4- 5)");
			private
				int size;// колво символов в формулы
			string formula;// формула в строковом формате ( ! реплейсом можно заменить переменные x,y,z на значения !)
			String[] funct;// формула в массиве
			string[] copyFormula;// формула в строковом формате (копия) для сокращения до результата
			double result;// результирующее значение функции

			// конструктор класса
			public FORMULAPARSING(string formula)
			{
				this.formula = formula;
				// парсинг формулы на массив посимвольно
				splitFunction();
				// вычисление значения функции из массива
				result = readFunctionFromArr();
			}

			// вернет строку формулы
			public string getFormula() { return this.formula; }

			// результирующее значение функции
			public double getResult() { return this.result; }

			// вычисление значения функции из массива
			private double readFunctionFromArr()
			{
				double resultY = 0;
				bool setY = false;// момент, когда пора вычислить значение у
				int i = 0;
				int open_pos = 0;// позиция открытой скобки
				int close_pos = 0;// позиция закрытой скобки
				int tmpSize = this.size;// колво элементов в формуле
										// массив значений функции
				this.copyFormula = new string[this.size];
				// создание копии массива для его последовательного преобразования в результат
				Array.Copy(this.funct, this.copyFormula, this.size);

				// обходим массив, пока в его последнем элементе не останется результат вычисления
				while (tmpSize != 1)
				{
					// открытая скобка и первая закрытая. Получим внутренние скобки
					if (this.copyFormula[i] == ")" && close_pos == 0)
					{
						close_pos = i;
						int n = i;
						// поиск позиции открытой скобки
						while (--n != 0)
						{
							if (this.copyFormula[n] == "(")
							{
								open_pos = n;
								setY = true;
								break;
							}
						}
					}

					if (setY || (++i == tmpSize))
					{
						i = 0;
						setY = false;
						if (close_pos == 0) close_pos = tmpSize;
						// получение значения в скобках
						resultY = getValueOfBrackets(ref open_pos, close_pos);
						resultY = myMath(resultY, open_pos - 1, tmpSize);
						// удаление из массива пустых ячеек и скобок, если там только результат: [(][][11][][)]
						updateArray(ref tmpSize, open_pos, close_pos);
						open_pos = close_pos = 0;// сброс позиций скобок
					}
				}// while

				return resultY;
			}


			// ДОПОЛНИТЕЛЬНЫЕ МЕТОДЫ
			// парсинг формулы на массив посимвольно (скобка в один элемент, математическая операция, значение в другой элемент
			private void splitFunction()
			{
				// удалим все пробелы и другие лишние символы из строки формулы 20 * Sin(Sqrt(x) * 3
				this.formula = this.formula.Replace(" ", "");
				this.formula = this.formula.Replace(";", "");

				// объявление переменных
				int index = 0; // индекс элемента массива
				int len = this.formula.Length;// длина формулы
				this.funct = new String[len];// массив значений функции
				char currentSymbol;// текущий символ
				bool isNumber = false;//текущий символ число
				string sNumber = ""; // формируемое число, стостоящее из одной и более цифр
				string fun = "";// хранит название математических функций (log, cos, sin)

				// обход каждого символа формулы
				for (int i = 0; i < len; i++)
				{
					currentSymbol = Convert.ToChar(this.formula.Substring(i, 1));
					// текущий символ число или плавающая запятая, считываем в переменную
					if (Char.IsNumber(currentSymbol) || currentSymbol == '.' || currentSymbol == ',')
					{
						isNumber = true;
						sNumber += currentSymbol;
						// запишем число, состоящее из одного или более чисел в элемент массива
						if (i + 1 == len) this.funct[index++] = sNumber;
					}
					// текущий символ латинская буква
					else if (char.IsLetter(currentSymbol))
					{
						fun += Convert.ToString(currentSymbol);
						// запишем функцию(log,cos,sin...) в элемент массива
						if (i + 1 == len) this.funct[index++] = fun;
					}
					else
					{// запишем данные в массив
						if (isNumber)// запишем число в массив
						{
							isNumber = false;
							// запишем число в элемент массива
							this.funct[index++] = sNumber;
							sNumber = "";// обнулим
						}
						// запишем математическую функцию (x, sin, con..) в массив
						if (fun != "")
						{
							this.funct[index++] = fun.ToLower();
							fun = "";
						}

						// запишем дргие спец символы в элемент массива
						if (currentSymbol == '(') this.funct[index++] = "(";
						else if (currentSymbol == ')') this.funct[index++] = ")";
						else if (currentSymbol == '*' || currentSymbol == '/' || currentSymbol == '-' || currentSymbol == '+' || currentSymbol == '^')
							this.funct[index++] = Convert.ToString(currentSymbol);
					}
				}//for
				 // колво значений в массиве [(][33][+][5][)]
				this.size = index;
			}


			// вернет значение в скобках, например х: (х) или Sqr(x+1)
			private double getValueOfBrackets(ref int j, int end)
			{
				// функция сможет принимать значение Х, которая хранит любое число
				double result = 1;
				int main = -1;// основные опреации * / 
				bool bIncDic = false;// время складывать и вычитать


				// поиск значений в степени
				for (int i = j; i < end; i++)
				{
					if (this.copyFormula[i] == "^")
					{
						j = i;
						return Convert.ToDouble(this.copyFormula[i + 1]);
					}
				}


				// если в скобках нет математических выражений (+-*/) вычислим сивол и вернем его
				if (end - (j + 1) == 1)
				{
					return Convert.ToDouble(this.copyFormula[j + 1]);
				}


				for (int i = j; i < end; i++)
				{
					// определим опрецию (* /)
					if (!bIncDic && (this.copyFormula[i] == "*" || this.copyFormula[i] == "/")) main = 1;
					// определим опрецию (+ -)
					if (i + 1 == end || bIncDic)
					{
						if (!bIncDic) i = j;
						bIncDic = true;
						if ((this.copyFormula[i] == "+" || this.copyFormula[i] == "-")) main = 0;
					}


					if (main >= 0)
					{
						// определим значения 'd1, d2'
						double d1 = 0, d2 = 0;
						// значение перед знаком (X или число)
						int n = i - 1;//будем пропускать пустые элементы
						while (this.copyFormula[n] == "") n--;
						d1 = Convert.ToDouble(this.copyFormula[n]);
						// значение после знака (X или число)
						int k = i + 1;
						while (this.copyFormula[k] == "") k++;
						d2 = Convert.ToDouble(this.copyFormula[k]);

						// вычислим результат
						if (main == 1)
						{
							if (this.copyFormula[i] == "*") result = d1 * d2;
							if (this.copyFormula[i] == "/") result = d1 / d2;
						}
						if (main == 0)
						{
							if (this.copyFormula[i] == "+") result = d1 + d2;
							if (this.copyFormula[i] == "-") result = d1 - d2;
						}

						this.copyFormula[i] = result.ToString();
						this.copyFormula[n] = this.copyFormula[k] = "";
						main = -1;
					}
				}// for i

				return result;
			}


			// вычислит значение по заданной функции Math
			private double myMath(double d, int fun_pos, int size)
			{
				if (fun_pos < 0) return d;
				if (this.copyFormula[fun_pos] == "sin") d = Math.Sin(d);
				else if (this.copyFormula[fun_pos] == "cos") d = Math.Cos(d);
				else if (this.copyFormula[fun_pos] == "sqrt") d = Math.Sqrt(Math.Abs(d));
				else if (this.copyFormula[fun_pos] == "tg") d = Math.Tan(d);
				else if (this.copyFormula[fun_pos] == "e" && this.copyFormula[fun_pos + 1] == "^") d = Math.Pow(Math.E, d);
				else if (this.copyFormula[fun_pos + 1] == "^") d = Math.Pow(Convert.ToDouble(this.copyFormula[fun_pos]), d);// SQRT
				else return d;// вернем неизмененное значение, если в формуле отсутствуют математические функции

				// заменим функцию на результат: sin(x) = x. очистив не нужные элементы
				this.copyFormula[fun_pos] = d.ToString();

				// очистим если степень
				if (this.copyFormula[fun_pos + 1] == "^")
				{
					this.copyFormula[fun_pos + 1] = "";
					this.copyFormula[fun_pos + 2] = "";
					return d;
				}

				// очистим если функция
				int n = fun_pos + 1;
				while (this.copyFormula[n] != ")") this.copyFormula[n++] = "";
				this.copyFormula[n] = "";

				return d;
			}


			// удаление из массива пустых ячеек и скобок, если там только результат
			private void updateArray(ref int size, int open_pos, int close_pos)
			{
				// убедимся, что между заданными скобками остался только результат
				bool bRemoveBrackeds = false;// удалить скобки
											 // убедимся, что скобки существуют
				if (this.copyFormula[open_pos] == "(" && this.copyFormula[close_pos] == ")") bRemoveBrackeds = true;
				for (int i = open_pos; i < close_pos; i++)
				{
					// не удалять скобки, там еще нет результата
					if (this.copyFormula[i] == "+" || this.copyFormula[i] == "-" ||
						this.copyFormula[i] == "*" || this.copyFormula[i] == "/")
					{
						bRemoveBrackeds = false;
						break;
					}
				}

				// если скобки нужно удалить, просто сотрем их пустым значением
				if (bRemoveBrackeds)
				{
					this.copyFormula[open_pos] = "";
					this.copyFormula[close_pos] = "";
				}


				int count = 0;
				for (int i = 0; i < size; i++)
				{
					if (this.copyFormula[i] != "") count++;
				}

				// перезапишем изменения в новый массив
				string[] newArr = new string[count];
				int inx = 0;
				for (int i = 0; i < size; i++)
				{
					if (this.copyFormula[i] != "") newArr[inx++] = this.copyFormula[i];
				}

				this.copyFormula = newArr;
				size = count;
			}

		};





		private void построитьToolStripMenuItem_Click(object sender, EventArgs e)// функция при нажатии на кнопку построить в Menustrip
        {
            double x, y;
            if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" )// проверка на наличие символов в текстбоксах
            {
                MessageBox.Show("Необходимо заполнить все поля!", "Ошибка",// если нет выводит ошибку
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            double a = Convert.ToDouble(textBox1.Text);// считываем переменные из текст боксов(дробные с ,)
            double b = Convert.ToDouble(textBox2.Text);
            double h = Convert.ToDouble(textBox3.Text);

            if (h == 0 || h > 1 || h < 0)
            {
                MessageBox.Show("некорректные данные в поле е (1>e>0)", "что-то не так",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            this.chart1.Series[0].Points.Clear();//чистим график перед тем как построить новый
            x = a;
            while (x <= b) //строим график с шагом(точностью) e = h (точность в программе обозначается h)
            {
                //y = x * x - 5 * x + 4;
                string value = textBox4.Text.Replace("x", Convert.ToString(x));
                FORMULAPARSING fm = new FORMULAPARSING(value);
                y = fm.getResult();
                this.chart1.Series[0].Points.AddXY(x, y);
                x += h;
            }
        }

        //функция при нажатии на кнопку отчистить в Menustrip 
        private void отчиститьToolStripMenuItem_Click(object sender, EventArgs e) 
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            this.chart1.Series[0].Points.Clear();

        }

        // функция при нажатии на кнопку найти минимум в MenuStrip
        private void найтиМинимумToolStripMenuItem_Click(object sender, EventArgs e) 
        {
            if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "")
            {
                MessageBox.Show("не все поля заполнены", "что-то не так",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            double x = 0;
            double a = Convert.ToDouble(textBox1.Text);
            double b = Convert.ToDouble(textBox2.Text);
            double h = Convert.ToDouble(textBox3.Text);
            if (h == 0 || h > 1 || h < 0)
            {
                MessageBox.Show("некорректные данные в поле е (1>e>0)", "что-то не так",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            // ниже приведен метод дихотомии 
            // Точность.
            double accuracy = h;
            // Интервал поиска.
            double startspot = a;
            double finishspot = b;
            // Длина интервала.
            var length = finishspot - startspot;

            while (length > accuracy && (x * x  - 5 * x + 4) != 0)
            {
                // Вычисляем середину интервала.
                x = (startspot + finishspot) / 2;
                // Найдём новый интервал, в котором функция меняет знак.
                if ((x * x - 5 * x + 4) * (startspot * startspot - 5 * startspot + 4) < 0)
                {
                    finishspot = x;
                }
                else if ((finishspot * finishspot - 5 * finishspot + 4) * (x * x - 5 * x + 4) < 0)
                {
                    startspot = x;
                }
                else finishspot -= 0.1;
                // Вычисляем новую длинну.
                length = (finishspot - startspot);
            }
            textBox5.Text = Convert.ToString(x);

        }
        // функция проверки вводимых символов  для 1ого 2ого и 3его текст боксов
        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (!Char.IsDigit(ch) && ch != 8 && ch != 44 && ch != 45 && ch != 127 && ch != 46)
            {
                MessageBox.Show("некорректные данные", "что-то не так",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                e.Handled = true;
            }
            
        }
        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (!Char.IsDigit(ch) && ch != 8 && ch != 44 && ch != 45 && ch != 127 && ch != 46)
            {
                MessageBox.Show("некорректные данные", "что-то не так",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                e.Handled = true;
            }
            
        }

        //не даем вводить данные в текст бокс5 у нас там будет выводится минимум! 
        private void textBox5_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            e.Handled = true;
        }
    }
}
